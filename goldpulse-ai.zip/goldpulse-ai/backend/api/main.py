"""GoldPulse AI – FastAPI application (Phase 1).

Run from the project folder:
    python -m uvicorn backend.api.main:app --host 127.0.0.1 --port 8010
"""
from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend import __version__
from backend.config import Settings, load_settings
from backend.data.base import TIMEFRAMES, DataUnavailableError
from backend.data.market_service import STATUS_UNAVAILABLE, MarketService


def build_provider(settings: Settings):
    if settings.resolved_provider == "twelvedata":
        from backend.data.twelvedata_provider import TwelveDataProvider

        return TwelveDataProvider(settings)
    from backend.data.xaus_provider import XausProvider

    return XausProvider(settings)


def create_app(service: MarketService | None = None, settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    if service is None:
        service = MarketService(build_provider(settings), settings)

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        yield
        service.provider.shutdown()

    app = FastAPI(
        title="GoldPulse AI – Live Gold Market Intelligence",
        version=f"{__version__} (Phase 1)",
        description="Independent XAUUSD market data and indicators (no MT5, no broker connection, no trading).",
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.cors_origins),
        allow_methods=["GET"],
        allow_headers=["*"],
    )

    def unavailable(exc: Exception, **extra) -> JSONResponse:
        return JSONResponse({"status": STATUS_UNAVAILABLE, "status_reason": str(exc), **extra}, status_code=503)

    def check_tf(timeframe: str) -> str:
        tf = timeframe.upper()
        if tf not in TIMEFRAMES:
            raise HTTPException(status_code=400, detail=f"timeframe must be one of {list(TIMEFRAMES)}")
        return tf

    @app.get("/api/health")
    def health():
        body = service.health()
        return JSONResponse(body, status_code=503 if body["status"] == STATUS_UNAVAILABLE else 200)

    @app.get("/api/price")
    def price():
        body = service.price_snapshot()
        return JSONResponse(body, status_code=503 if body["status"] == STATUS_UNAVAILABLE else 200)

    @app.get("/api/candles/{timeframe}")
    def candles(timeframe: str, count: int = Query(200, ge=10, le=2000)):
        tf = check_tf(timeframe)
        try:
            return service.candles_payload(tf, count)
        except DataUnavailableError as exc:
            return unavailable(exc, timeframe=tf)

    @app.get("/api/technicals")
    def technicals_all():
        return service.technicals_all()

    @app.get("/api/technicals/{timeframe}")
    def technicals(timeframe: str):
        tf = check_tf(timeframe)
        try:
            return service.technicals(tf)
        except DataUnavailableError as exc:
            return unavailable(exc, timeframe=tf)

    @app.get("/")
    def root():
        return {
            "app": "GoldPulse AI",
            "phase": 1,
            "docs": "/docs",
            "endpoints": ["/api/health", "/api/price", "/api/candles/{tf}", "/api/technicals", "/api/technicals/{tf}"],
            "timeframes": list(TIMEFRAMES),
        }

    return app


app = create_app()
